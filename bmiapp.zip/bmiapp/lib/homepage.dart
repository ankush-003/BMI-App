import 'package:flutter/material.dart';
double height=150;
double weight=60;

class HomePage extends StatefulWidget {
  const HomePage({Key? key}) : super(key: key);

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      appBar: AppBar(
        backgroundColor: Colors.white24,
        title: Text("BMI Calculator"),
      ),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.spaceEvenly,
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [

            Container(
              decoration: BoxDecoration(
                  border: Border.all(
                    color: Colors.white,
                  ),
                  borderRadius: BorderRadius.all(Radius.circular(20))
              ),
              height: 250,
              width: 250,
              child: Column(
                children: [
                  Text(
                      'HEIGHT',
                      style: TextStyle(
                          color: Colors.white,
                          fontWeight: FontWeight.bold,
                          fontSize: 20)
                  ),
                  Padding(
                    padding: const EdgeInsets.all(30.0),
                    child: Text("${height.round()}",
                        style: TextStyle(
                            color: Colors.white,
                            fontWeight: FontWeight.bold,
                            fontSize: 20)),
                  ),
                  Slider(
                    activeColor: Colors.white,
                    inactiveColor: Colors.white30,
                    thumbColor: Colors.redAccent,
                    value: height,
                    max: 200,
                    min: 100,
                    onChanged: (newValue) {
                      setState(() {
                        height = newValue;
                      });
                    },
                  )
                ],
              ),
            ),
            Container(
              decoration: BoxDecoration(
                  border: Border.all(
                    color: Colors.white,
                  ),
                  borderRadius: BorderRadius.all(Radius.circular(20))
              ),
              height: 250,
              width: 250,
              child: Column(
                children: [
                  Text(
                      'WEIGHT',
                      style: TextStyle(
                          color: Colors.white,
                          fontWeight: FontWeight.bold,
                          fontSize: 20)
                  ),
                  Padding(
                    padding: const EdgeInsets.all(30.0),
                    child: Text("${weight.round()}",
                        style: TextStyle(
                            color: Colors.white,
                            fontWeight: FontWeight.bold,
                            fontSize: 20)),
                  ),
                  Slider(
                    activeColor: Colors.white,
                    inactiveColor: Colors.white30,
                    thumbColor: Colors.redAccent,
                    value: weight,
                    max: 120,
                    min: 20,
                    onChanged: (newValue) {
                      setState(() {
                        weight = newValue;
                      });
                    },
                  )
                ],
              ),
            ),

          ],
        ),
      ),
    );
  }
}
