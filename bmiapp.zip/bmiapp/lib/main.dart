import 'package:flutter/material.dart';
import 'package:bmiapp/bmipage.dart';
import'package:flutter_rating_bar/flutter_rating_bar.dart';
import 'package:gender_picker/source/enums.dart';
import 'package:gender_picker/source/gender_picker.dart';
void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({Key? key}) : super(key: key);

  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: HomePage(),
    );
  }
}

double height=150;
double weight=60;
class HomePage extends StatefulWidget {
  const HomePage({Key? key}) : super(key: key);

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  @override
  Widget build(BuildContext context) {

    return Scaffold(
      backgroundColor: Colors.black,
      appBar: AppBar(
        backgroundColor: Colors.white24,
        title: Text("BMI Calculator"),
      ),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.spaceEvenly,
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            getWidget(false, false),
            Container(
              decoration: BoxDecoration(
                  border: Border.all(
                    color: Colors.white,
                  ),
                  borderRadius: BorderRadius.all(Radius.circular(20))
              ),
              height: 200,
              width: 300,
              child: Column(
                children: [
                  Text(
                      'HEIGHT',
                      style: TextStyle(
                          color: Colors.white,
                          fontWeight: FontWeight.bold,
                          fontSize: 20)
                  ),
                  Padding(
                    padding: const EdgeInsets.all(30.0),
                    child: Text("${height.round()} cm",
                        style: TextStyle(
                        color: Colors.white,
                        fontWeight: FontWeight.bold,
                        fontSize: 20)),
                  ),
                  Slider(
                    activeColor: Colors.white,
                    inactiveColor: Colors.white30,
                    thumbColor: Colors.redAccent,
                    value: height,
                    max: 200,
                    min: 100,
                    onChanged: (newValue) {
                      setState(() {
                        height = newValue;
                      });
                    },
                  )
                ],
              ),
            ),
            Container(
              decoration: BoxDecoration(
                  border: Border.all(
                    color: Colors.white,
                  ),
                  borderRadius: BorderRadius.all(Radius.circular(20))
              ),
              height: 200,
              width: 300,
              child: Column(
                children: [
                  Text(
                      'WEIGHT',
                      style: TextStyle(
                          color: Colors.white,
                          fontWeight: FontWeight.bold,
                          fontSize: 20)
                  ),
                  Padding(
                    padding: const EdgeInsets.all(30.0),
                    child: Text("${weight.round()} Kg",
                        style: TextStyle(
                            color: Colors.white,
                            fontWeight: FontWeight.bold,
                            fontSize: 20)),
                  ),
                  Slider(
                    activeColor: Colors.white,
                    inactiveColor: Colors.white30,
                    thumbColor: Colors.redAccent,
                    value: weight,
                    max: 120,
                    min: 20,
                    onChanged: (newValue) {
                      setState(() {
                        weight = newValue;
                      });
                    },
                  )
                ],
              ),
            ),
            ElevatedButton(
                style: ElevatedButton.styleFrom(
                primary: Colors.white, // background
                onPrimary: Colors.black,// foreground
                ),
                onPressed:() {

              Navigator.push(
                context,
                MaterialPageRoute(builder: (context) => bmipage(bmi: (weight/(height*height))*10000)),
              );
            }, child: Text("Calculate BMI",
            style: TextStyle(
              fontSize: 18,
              fontWeight: FontWeight.bold,
            ))),
          ],
        ),
      ),
    );
  }
}
Widget getWidget(bool showOtherGender, bool alignVertical) {
  return Container(
    margin: EdgeInsets.symmetric(vertical: 40),
    alignment: Alignment.center,
    child: GenderPickerWithImage(
      showOtherGender: showOtherGender,
      verticalAlignedText: alignVertical,

      // to show what's selected on app opens, but by default it's Male
      selectedGender: Gender.Male,
      selectedGenderTextStyle: TextStyle(
          color: Colors.redAccent, fontWeight: FontWeight.bold),
      unSelectedGenderTextStyle: TextStyle(
          color: Colors.white, fontWeight: FontWeight.bold),
      onChanged: (Gender? gender) {
        print(gender);
      },
      //Alignment between icons
      equallyAligned: true,

      animationDuration: Duration(milliseconds: 300),
      isCircular: true,
      // default : true,
      opacityOfGradient: 0.4,
      padding: const EdgeInsets.all(3),
      size: 60, //default : 40
    ),
  );
}
