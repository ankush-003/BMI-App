package com.example.bmiapp

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
